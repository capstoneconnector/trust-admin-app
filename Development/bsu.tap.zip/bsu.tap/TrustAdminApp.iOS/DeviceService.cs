﻿using TrustAdminApp;
using TrustAdminApp.iOS;
using UIKit;

using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: Dependency(typeof(DeviceService))]
namespace TrustAdminApp.iOS
{
    class DeviceService : IDeviceService
    {
        public bool GetApplicationNotificationSettings()
        {
            var settings = UIApplication.SharedApplication.CurrentUserNotificationSettings.Types;
            return settings != UIUserNotificationType.None;
        }
    }
}
