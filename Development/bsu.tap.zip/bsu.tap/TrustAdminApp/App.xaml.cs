﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using TrustAdminApp.Views;
using ASC.Trust.API.SDK;

namespace TrustAdminApp
{
    public partial class App : Application
    {
        public HandlerFactory handlerFactory;
        public App()
        {
            InitializeComponent();

            MainPage = new AppShell();
        }
        public HandlerFactory HandlerFactory
        {
            get { return handlerFactory; }
            set
            {
                handlerFactory = value;
            }
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
