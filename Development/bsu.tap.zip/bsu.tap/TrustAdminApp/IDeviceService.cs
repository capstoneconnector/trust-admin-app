﻿using System;
namespace TrustAdminApp
{
    public interface IDeviceService
    {
        bool GetApplicationNotificationSettings();
    }
}
