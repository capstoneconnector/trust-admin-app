﻿using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TrustAdminApp.ViewModels
{
    public class ReviewsViewModel : BaseViewModel
    {
        public ReviewsViewModel()
        {
            Title = "Reviews";
        }
    }
}