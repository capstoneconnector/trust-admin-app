﻿using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using TrustAdminApp.Views;
using ASC.Trust.API.SDK;

namespace TrustAdminApp.ViewModels
{
    public class SettingsViewModel : BaseViewModel
    {
        public ICommand LogoutCommand { protected set; get; }
        public SettingsViewModel()
        {
            LogoutCommand = new Command(OnLogout);
            Title = "Settings";
        }
        public async void OnLogout()
        {
            try
            {
                var email = await SecureStorage.GetAsync("email");
                Console.WriteLine(email);
            }
            catch (Exception ex)
            {
                // Possible that device doesn't support secure storage on device.
                Console.WriteLine(ex);
            }
            SecureStorage.RemoveAll();
            await Shell.Current.GoToAsync($"//{nameof(LoginPage)}");
        }
    }
}