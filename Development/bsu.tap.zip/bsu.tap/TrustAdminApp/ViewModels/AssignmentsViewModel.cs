﻿using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace TrustAdminApp.ViewModels
{
    public class AssignmentsViewModel : BaseViewModel
    {
        public AssignmentsViewModel()
        {
            Title = "Assignments";
        }
    }
}