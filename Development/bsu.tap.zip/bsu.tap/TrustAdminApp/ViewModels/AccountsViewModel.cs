﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Xamarin.Essentials;
using Xamarin.Forms;
using ASC.Trust.API.SDK;
using TrustAdminApp.Services;
using TrustAdminApp.Views;
using System.Collections.ObjectModel;

namespace TrustAdminApp.ViewModels
{    public class AccountsViewModel : BaseViewModel
    {
        public ObservableCollection<ASC.Trust.API.SDK.Models.Response.AccountApiModel> Accounts;

        public AccountsViewModel()
        {
            Title = "Accounts";
            FetchAccounts();
            Accounts = new ObservableCollection<ASC.Trust.API.SDK.Models.Response.AccountApiModel>();
        }
        public async void FetchAccounts()
        {
            try
            {
                Logging logging = new Logging();
                var logger = logging.NewLogger("Hello");
                var username = await SecureStorage.GetAsync("username");
                var password = await SecureStorage.GetAsync("password");
                var url = await SecureStorage.GetAsync("baseURL");
                var key = await SecureStorage.GetAsync("apiKey");
                if (username != "" && password != "")
                {
                    var handlerFactory = new HandlerFactory(username, password, url, key, logger);
                    var accountHandler = handlerFactory.CreateHandler<AccountHandler>();
                    var response = await accountHandler.Accounts();
                    if (response.IsSuccessful)
                    {
                        foreach(var account in response.Data)
                        {
                            Accounts.Add(account);
                        }
                    }
                } 
                else
                {
                    //Email and password are null, redirect to login page
                    SecureStorage.RemoveAll();
                    await Shell.Current.GoToAsync($"//{nameof(LoginPage)}");
                }

            } catch (Exception ex)
            {
                // Possible that device doesn't support secure storage
                Console.WriteLine("Error: " + ex);

            }

        }
    }
}