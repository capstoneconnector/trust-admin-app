﻿using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using System.ComponentModel;
using ASC.Trust.API.SDK;
using Xamarin.Forms.Internals;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using TrustAdminApp;
using TrustAdminApp.Views;

namespace TrustAdminApp.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        private string username;
        private string password;
        public string Username
        {
            get { return username; }
            set
            {
                username = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Username"));
            }
        }
        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Password"));
            }
        }
        public ICommand SubmitCommand { protected set; get; }
        public ICommand CheckCommand { protected set; get; }
        public LoginViewModel()
        {
            SubmitCommand = new Command(OnSubmit);
            Title = "Login";
        }
        public async void OnSubmit()
        {
            //((App)App.Current).handlerFactory = new HandlerFactory();
            try
            {
                Console.WriteLine("hell0");
                if (username != "" && password != "")
                {
                    var loggerConfig = new NLog.Config.LoggingConfiguration();
                    var loggerFactory = (ILoggerFactory)new LoggerFactory();
                    var fileTarget = new NLog.Targets.FileTarget()
                    {
                        Name = "logfile",
                        FileName = "log.txt",
                        Layout = "${longdate}|${level:uppercase=true}|${logger}|${event-context:item=EventId}|${message}|${ndc}"
                    };
                    loggerConfig.AddTarget(fileTarget);
                    loggerConfig.LoggingRules.Add(new NLog.Config.LoggingRule("*", NLog.LogLevel.Info, fileTarget));
                    loggerFactory.AddNLog();
                    var logger = loggerFactory.CreateLogger("Hello");
                    var handlerFactory = new HandlerFactory(username, password, "https://asctrustv64webapi.accutech-systems.net", "LEfo9UzroI4DIVxf6WCM9hSbpgDj5HPmRJLiKFwQyLs1n9yLAZ24IB84ovDzD0d8qesBwx9cl7pcRlvs4cR2yc0XLzemokajinjuKybl8Ju4cjuBZogDNWUcasnDwXit", logger);
                    var accountHandler = handlerFactory.CreateHandler<AccountHandler>();
                    var test = await accountHandler.Account(1);
                    if (test.IsSuccessful)
                    {
                        await SecureStorage.SetAsync("username", username);
                        await SecureStorage.SetAsync("password", password);
                        await SecureStorage.SetAsync("baseURL", "https://asctrustv64webapi.accutech-systems.net");
                        await SecureStorage.SetAsync("apiKey", "LEfo9UzroI4DIVxf6WCM9hSbpgDj5HPmRJLiKFwQyLs1n9yLAZ24IB84ovDzD0d8qesBwx9cl7pcRlvs4cR2yc0XLzemokajinjuKybl8Ju4cjuBZogDNWUcasnDwXit");
                        var saveduser = await SecureStorage.GetAsync("username");
                        Console.WriteLine(saveduser);
                        await Shell.Current.GoToAsync($"//{nameof(SettingsPage)}");
                    }
                }
                
            }
            catch (Exception ex)
            {
                // Possible that device doesn't support secure storage on device.
                Console.WriteLine(ex);
            }
        }
    }
}