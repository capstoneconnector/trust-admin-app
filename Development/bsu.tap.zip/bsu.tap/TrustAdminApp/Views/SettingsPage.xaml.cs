﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;
using System;
namespace TrustAdminApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SettingsPage : ContentPage
    {
        public SettingsPage()
        {
            InitializeComponent();
            TaskUpdatesSwitch.IsToggled = Preferences.Get("TaskUpdatesSwitch", false);
            ReviewUpdatesSwitch.IsToggled = Preferences.Get("ReviewUpdatesSwitch", false);
            TaskUpdatesSwitch.Toggled += TaskUpdatesSwitch_Toggled;
            ReviewUpdatesSwitch.Toggled += ReviewUpdatesSwitch_Toggled;
        }
        void TaskUpdatesSwitch_Toggled(System.Object sender, Xamarin.Forms.ToggledEventArgs e)
        {
            Preferences.Set("TaskUpdatesSwitch", TaskUpdatesSwitch.IsToggled);
        }
        void ReviewUpdatesSwitch_Toggled(System.Object sender, Xamarin.Forms.ToggledEventArgs e)
        {
            Preferences.Set("ReviewUpdatesSwitch", ReviewUpdatesSwitch.IsToggled);
        }
    }
}