﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;

namespace TrustAdminApp.Services
{
    class Logging
    {
        private ILoggerFactory loggerFactory;
        public Logging()
        {
            loggerFactory = new LoggerFactory();
            var loggerConfig = new NLog.Config.LoggingConfiguration();
            var fileTarget = new NLog.Targets.FileTarget()
            {
                Name = "logfile",
                FileName = "log.txt",
                Layout = "${longdate}|${level:uppercase=true}|${logger}|${event-context:item=EventId}|${message}|${ndc}"
            };
            loggerConfig.AddTarget(fileTarget);
            loggerConfig.LoggingRules.Add(new NLog.Config.LoggingRule("*", NLog.LogLevel.Info, fileTarget));
            loggerFactory.AddNLog();
        }

        public ILogger NewLogger(string categoryName)
        {
            return loggerFactory.CreateLogger(categoryName);
        }
    }
}
